Name: Jaden Towey

Student ID: 2420751

Chapman email: towey@chapman.edu

Course: CPSC231

Section: 04

Assignment: MP4_Music

Source Files: Account.java , Comparable.java , ListenableContent.java, Song.java


References: N/A

To run:
I know it does not run but I tried so hard and thought it was better to submit this than nothing 
I'm so so sorry 