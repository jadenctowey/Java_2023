1. identifying information:
    1. Jaden Towey
    2. 002420751
    3. towey@chapman.edu
    4. CPSC 298 - 01
2. MP1: Drawing with 2D Arrays 
3. Drawing.java
   README.txt
5. Arohi Yadav
   