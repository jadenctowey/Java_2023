Name: Jaden Towey

Student ID: 2420751

Chapman email: towey@chapman.edu

Course: CPSC231

Section: 04

Assignment: MP2_Pizza

Source Files: Pizza.java , PizzaDriver.java , PizzaOrder.java


References: N/A

To run:
javac PizzaDriver.java
java PizzaDriver