Name: Jaden Towey

Student ID: 2420751

Chapman email: towey@chapman.edu

Course: CPSC231

Section: 04

Assignment: MP3A_Cards

Source Files: Card.java , Deck.java , Dealer.java, TestCards.java


References: 
Sami Hammoud 
Andrew Bahsoun

To run:
javac TestCards.java
java TestCards